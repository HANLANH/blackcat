# SeoulBikeConsoleApplication
서울시 공공자전거 데이터를 활용한 자바 기반 콘솔 애플리케이션입니다

